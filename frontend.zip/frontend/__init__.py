"""CRICFIT AI Frontend Package."""
