"""
CRICFIT AI — Bowling Analysis Page
==================================
Allows cricketers to upload bowling run-up and delivery videos, run them
through the Action Filter + Arm/Pace Classifiers + Pro Bowler Reference Matcher + Groq AI,
and review the annotated video, targeted drills, diet guidelines, and PDF report.
"""

import time
import streamlit as st
from config import ALLOWED_VIDEO_TYPES, PAGES
from utils.session import navigate_to
from utils.helpers import validate_video_file, format_file_size
from services.api import analyze_video
from components.report_view import render_full_report_view


def render_bowling_page():
    """Render Bowling Analysis video upload & processing page."""

    if st.button("← Back to Home", key="btn_bowling_back_home", type="secondary"):
        navigate_to(PAGES["HOME"])

    # Show report if already analyzed
    if st.session_state.get("analysis_result") and st.session_state.get("selected_activity") == "bowling":
        def reset_analysis():
            st.session_state.analysis_result = None
            st.session_state.uploaded_video = None
            st.rerun()

        try:
            render_full_report_view(st.session_state.analysis_result, on_reset_callback=reset_analysis)
        except Exception as e:
            st.error(f"⚠️ Error displaying analysis report: {e}")
            if st.button("🔄 Try Uploading Again", key="btn_err_reset_bowling"):
                reset_analysis()
        return

    st.html("""
    <div style="margin-bottom:24px;">
        <h1 style="font-size:2.2rem;font-weight:900;margin:0;color:#FFFFFF;">
            &#x1F3C3; Bowling Biomechanics Analysis
        </h1>
        <p style="font-size:1.05rem;color:#94A3B8;margin-top:6px;">
            Upload your bowling video. CricFit AI will analyze your run-up gathering, delivery stride plant,
            trunk stability, and kinetic bowling chain, comparing your mechanics with elite international bowlers.
        </p>
    </div>
    """)

    uploaded_file = st.file_uploader(
        "Upload Bowling Video",
        type=ALLOWED_VIDEO_TYPES,
        key="bowling_uploader",
        help="Upload MP4, MOV, or AVI bowling run-up and delivery clip (Max 100MB)"
    )

    if uploaded_file is not None:
        is_valid, msg = validate_video_file(uploaded_file)
        if not is_valid:
            st.error(msg)
            return

        st.session_state.uploaded_video = uploaded_file

        st.html(f"""
        <div style="background:rgba(15,23,42,0.8);border:1px solid rgba(59,130,246,0.3);
                    border-radius:16px;padding:20px;margin:20px 0;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
                <div>
                    <span style="font-size:0.75rem;color:#10B981;font-weight:700;">
                        &#x2713; VIDEO READY FOR AI PIPELINE</span>
                    <h4 style="margin:4px 0 0 0;color:#FFFFFF;font-size:1.1rem;">{uploaded_file.name}</h4>
                </div>
                <span style="background:#1E293B;color:#94A3B8;padding:4px 10px;
                             border-radius:12px;font-size:0.8rem;">
                    Size: {format_file_size(uploaded_file.size)}
                </span>
            </div>
        </div>
        """)

        st.video(uploaded_file)

        if st.button("🚀 ANALYZE BOWLING ACTION", key="btn_run_bowling_analysis",
                     type="primary", use_container_width=True):
            with st.status("🤖 Evaluating Bowling Action, Matching Pro Bowlers & Querying Groq AI...", expanded=True) as status:
                st.write("Step 1/3: Verifying bowling action & delivery stride mechanics...")
                success, report_data, err_msg = analyze_video(uploaded_file, activity_type="bowling")

                if success and report_data:
                    status.update(label="✅ Analysis Complete!", state="complete", expanded=False)
                    st.session_state.analysis_result = report_data
                    st.session_state.selected_activity = "bowling"
                    st.rerun()
                else:
                    status.update(label="❌ Analysis Failed", state="error", expanded=True)
                    st.error(f"❌ {err_msg}")
    else:
        st.html("""
        <div style="border:2px dashed rgba(255,255,255,0.15);border-radius:20px;padding:40px;
                    text-align:center;background:rgba(15,23,42,0.4);margin-top:20px;">
            <div style="font-size:3rem;margin-bottom:10px;">&#x1F4F9;</div>
            <h4 style="color:#F8FAFC;margin:0 0 8px 0;">Upload your Bowling Video</h4>
            <p style="color:#94A3B8;font-size:0.9rem;margin:0;">
                Select a side-on or front-on video clip showing your approach run-up,
                jump/gather, front-foot plant, and release.
            </p>
        </div>
        """)
